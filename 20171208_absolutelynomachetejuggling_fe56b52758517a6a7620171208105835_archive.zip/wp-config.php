<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'machete' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '0000' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'pd@Ht[}ft9HUiwjPzZ2=V!P[-<E-gd,y_1oy)Y`19LP,{{b-dwVR9?|)7`<[FH:H' );
define( 'SECURE_AUTH_KEY',  '7uM*FDUDI#CqXHVODu]3_G4w<kubkHo{k<h)mfQX$W/yh##4Wvn]kk[ad:VYi;r3' );
define( 'LOGGED_IN_KEY',    'O]xjdhZnr3x0>Yz7TZ7T-uf{$EB7<1*+hmwTKl[jeU/LN&Z>1p-TECi-Q&Dmn[b&' );
define( 'NONCE_KEY',        'n0}0VW7,tE?]xxN~E506,/t>o`93>aEGjUuE/1e 6O/>a2J%VSMUS5kX8@PT|o-,' );
define( 'AUTH_SALT',        '}B%=Rd{+6T^%<_P/?pr)iG%k#1:G09bki|Z(QSW[t=02{Tz2{U[1^0d=Sd| nr@u' );
define( 'SECURE_AUTH_SALT', 'kZb=$z|+fs/u]MKH[mXO/v5#||TB*v}I0mOLKgH&}mj_1zz}Hj*0M!=08joa{S[/' );
define( 'LOGGED_IN_SALT',   '(>i[1/UHYukTYGE39EK<I0b)rp.2qN,0Zbx#,PV0yI@k|BjWf@6DRlF*:_XNQPdS' );
define( 'NONCE_SALT',       'y}|}?|aQ6K2Zn6quDc@q*JtyBDr;G_Tm_vYm?UDtt>cM|*g)95WcwXhY4E+9 z`-' );

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) )
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
